package it.polito.tdp.parole;

/**
 * Sample Skeleton for 'Parole.fxml' Controller Class
 */


import it.polito.tdp.parole.model.Parole;
import it.polito.tdp.parole.model.ParoleArrayList;

import java.net.URL;
import java.util.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ParoleController {
	
	Parole elenco ;
	ParoleArrayList elencoArray = new ParoleArrayList();
	
	long time = 0;
	long timeArray = 0;
	
	long sumTime = 0;
	long sumTArray = 0;
	
	String tempo = "";
	String tempoArray = "";
	
	long diff = 0;

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="txtParola"
    private TextField txtParola; // Value injected by FXMLLoader

    @FXML // fx:id="txtResult"
    private TextArea txtResult; // Value injected by FXMLLoader
    
    @FXML // fx:id="txtTime"
    private TextArea txtTime;
    
    @FXML // fx:id="txtResultArray"
    private TextArea txtResultArray;
    
    @FXML // fx:id="txtTimeArray"
    private TextArea txtTimeArray;
    
    @FXML
    private Button btnReset;

    @FXML // fx:id="btnInserisci"
    private Button btnInserisci; // Value injected by FXMLLoader
    

    @FXML // fx:id="txtPiuVeloce"
    private TextArea txtPiuVeloce; // Value injected by FXMLLoader

    @FXML
    void doInsert(ActionEvent event) {
    	// TODO
    	String parola = txtParola.getText();
    	
    	if(parola.length()!=0) {
    		
    		this.aggiornaTxtResult(parola);
    		this.aggiornaTxtResultArray(parola);
    	}
    	
    	long t = this.piuVeloce();
    	if(t > 0)
			txtPiuVeloce.setText("La LinkedList � pi� veloce");
		if(t < 0)
			txtPiuVeloce.setText("L'ArrayList � pi� veloce");   
   
    }
    
    @FXML
    void doReset(ActionEvent event) {
    	// TODO
    	elenco.reset();
    	time = System.nanoTime();
    	sumTime += time;
    	tempo += Long.toString(time) + "\n";
		txtTime.setText(tempo);
    	txtResult.clear();
    	this.resettaArray();
    	
    	long t = this.piuVeloce();
    	if(t > 0)
			txtPiuVeloce.setText("La LinkedList � pi� veloce");
		if(t < 0)
			txtPiuVeloce.setText("L'ArrayList � pi� veloce");   
    }
    
    @FXML
    void doCancel(ActionEvent event) {
    	if(txtResult.getSelectedText()!=null) {
    		String selezionato = txtResult.getSelectedText();
    		elenco.rimuoviParola(selezionato);
    		String e = "";
    		for(String s:elenco.getElenco())
    			e += s + "\n";
    		txtResult.setText(e);
    		time = System.nanoTime();
    		sumTime += time;
    		tempo += Long.toString(time) + "\n";
    		txtTime.setText(tempo);
    	}
    	
    	if(txtResultArray.getSelectedText()!=null) {
    			String selezionato = txtResultArray.getSelectedText();
    			elencoArray.rimuoviParola(selezionato);
    			String e = "";
    			for(String s:elencoArray.getElenco())
    				e += s + "\n";
    			txtResultArray.setText(e);
        		timeArray = System.nanoTime();
        		sumTArray += timeArray;
        		tempoArray += Long.toString(timeArray) + "\n";
        		txtTimeArray.setText(tempoArray);
    		}
    }
    
    public void aggiornaTxtResult(String parola) {
    	
    	elenco.addParola(parola); 
    	List<String> lista = elenco.getElenco();
    	String e = "";
    	for(String s:lista) {
    		e += s + "\n";
    	}
    	txtResult.setText(e);
    	time = System.nanoTime();
    	sumTime += time;
    	tempo += Long.toString(time) + "\n";
		txtTime.setText(tempo);
    	txtParola.setText("");
    }
    
    public void aggiornaTxtResultArray(String parola) {
    	elencoArray.addParola(parola);
    	List<String> lista = elencoArray.getElenco();
    	
    	String e = "";
    	for(String s:lista)
    		e += s + "\n";
    	txtResultArray.setText(e);
    	time = System.nanoTime();
    	sumTime += time;
    	tempoArray += Long.toString(time) +"\n";
    	txtTimeArray.setText(tempoArray);
    }
    
    public void resettaArray() {
    	elencoArray.reset();
    	txtResultArray.clear();
    	time = System.nanoTime();
    	sumTime += time;
    	tempoArray += Long.toString(time) +"\n";
    	txtTimeArray.setText(tempoArray);
    }
    
    public long piuVeloce() {
    	if(time!=0 && timeArray!=0) {
    		long t = sumTime - sumTArray;
    		return t; 			
    	}
    	return 0;
    }
    
    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert txtParola != null : "fx:id=\"txtParola\" was not injected: check your FXML file 'Parole.fxml'.";
        assert txtResult != null : "fx:id=\"txtResult\" was not injected: check your FXML file 'Parole.fxml'.";
        assert btnInserisci != null : "fx:id=\"btnInserisci\" was not injected: check your FXML file 'Parole.fxml'.";

        elenco = new Parole() ;
        
    }
    
}

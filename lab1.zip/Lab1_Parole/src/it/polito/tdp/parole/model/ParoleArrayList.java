package it.polito.tdp.parole.model;

import java.util.*;

public class ParoleArrayList {
	private List<String> paroleArray = new ArrayList<String>();
	
	
	public ParoleArrayList(){

	}
	
	public void addParola(String p) {
		paroleArray.add(p);
	}
	
	public List<String> getElenco(){
		Collections.sort(paroleArray);
		return paroleArray;
	}
	
	public void reset() {
		// TODO
		paroleArray.clear();
	}
	
	public void rimuoviParola(String selezionato) {
		paroleArray.remove(selezionato);
	}
	
}
